export default interface IContact {
    id: number;
    name: string;
    email: string;
    phone: string;
}